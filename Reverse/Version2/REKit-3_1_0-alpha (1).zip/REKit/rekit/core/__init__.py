"""Shared analysis primitives."""
