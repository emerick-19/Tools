"""REKit — CTF reverse engineering and malware static triage."""
__version__ = "3.1.0a1"
